module.exports = require("@drvt/os/truffle-config")
