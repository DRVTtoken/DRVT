// Only in onboarding (not in aragonUI)
export const TITLE_ONBOARDING = `
  font-size: 40px;
  font-weight: 600;
  line-height: 1.5;
`
