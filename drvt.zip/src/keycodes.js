export default {
  enter: 13,
  esc: 27,
  up: 38,
  left: 37,
  down: 40,
  right: 39,
}
