module.exports = {
  DEFAULT_LOCAL_ENS_ADDRESS: '0x5f6F7E8cc7346a11ca2dEf8f827b7a0b612c56a1',
  DEFAULT_LOCAL_IPFS_GATEWAY: 'http://localhost:8080/ipfs',
}
